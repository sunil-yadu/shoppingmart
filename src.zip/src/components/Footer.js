import React from "react"

const Footer =() =>
{
    return(
        <div>

        {/* footer */}
   
    

        <div className="footer">
            <p>
                Copyright &copy All rights reserved |
                 Sunil Yaduvanshi
            </p>
           
            
        </div>
    </div>
    )
}
export default Footer