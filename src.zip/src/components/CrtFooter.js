import React from "react"
import './style/cart1.css'

const CrtFooter =() =>
{
    return(
        <div>

        {/* footer */}
   
    

        <div className="crt_footer">
            <p>
                Copyright &copy All rights reserved |
                 Sunil Yaduvanshi
            </p>
           
            
        </div>
    </div>
    )
}
export default CrtFooter